To export your own Library.xml from iTunes 

File -> Library -> Export Library

Make sure it is in the correct folder.   Of course iTUnes might change
UI and/or export format any time - so good luck :)
